package Lab6;

import java.util.Scanner;

public class TestIntMyStack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer value: ");
        int a = sc.nextInt();
        MyStack<Integer> s = new MyStack();
        
        for(int i=1; i<=a; i++){
            s.push(i);
        }
        System.out.println(s);
        System.out.println("The size of the stack is " + s.getSize());
        System.out.println("The element inside the stack is ");
        while(!s.isEmpty()){
            System.out.println(s.pop());
        }
    }
}
