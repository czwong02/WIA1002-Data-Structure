package Lab6;

public class TestMyStack {
    public static void main(String[] args) {
        MyStack<Character> s = new MyStack();
        s.push('a');
        s.push('b');
        s.push('c');
        System.out.println(s.toString());
        System.out.println("'b' is in the stack: " + s.search('b'));
        System.out.println("'k' is in the stack: " + s.search('k'));
        
        System.out.println("");
        
        MyStack<Integer> s2 = new MyStack();
        s2.push(1);
        s2.push(2);
        s2.push(3);
        System.out.println(s2.toString());
        System.out.println("6 is in the stack: " + s2.search(6));
    }
    
}
