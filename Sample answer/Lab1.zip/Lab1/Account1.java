package Lab1;

import java.util.ArrayList;

public class Account1 extends Account{
    private String name;
    private ArrayList<Transaction> transactions; // int primitive, Wrapper class - >Integer
    
    public Account1(String name, int id, double bal){
        super(id, bal);
        this.name = name;
        transactions = new ArrayList<>(); // null
    }

    public String getName() {
        return name;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }
    
    @Override
    public void withdraw(double amount){
        if (amount > this.getBalance()){
            System.out.println("Amount is larger than balance.");
            return;
        }
        this.setBalance(this.getBalance() - amount);
        transactions.add(new Transaction('W', amount, this.getBalance(), "Withdrawal"));
    }
    
    public void deposit(double amount){
        this.setBalance(this.getBalance() + amount);
        transactions.add(new Transaction('D', amount, this.getBalance(), "Deposit"));
    }
}
