package Lab1;

import java.util.ArrayList;

public class Q4 {
    public static void main(String[] args) {
        Account1 a = new Account1("George", 1122, 1000);
        a.setAnnualInterestRate(1.5);
        a.deposit(30);
        a.deposit(40);
        a.deposit(50);
        a.withdraw(5);
        a.withdraw(4);
        a.withdraw(2);
        System.out.println("Name: " + a.getName());
        System.out.println("Monthly interest rate: " + a.getMonthlyInterestRate());
        System.out.println("Balance: " + a.getBalance());
        ArrayList<Transaction> temp = a.getTransactions();
        
        System.out.println("List of transactions");
        for(Transaction t : temp){
            System.out.println(t.toString());
        }
    }
}
