package Lab1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Q1 {

    public static void main(String[] args) {
        // Part 1
        Scanner s;
        try {
            s = new Scanner(new FileInputStream("src\\Lab1\\lee_12345.txt"));
            while(s.hasNextLine()){
                String line = s.nextLine();
                System.out.println(line);
            }
            s.close();
            /*
            Using Buffered Reader
            BufferedReader br = new BufferedReader(new FileReader("src\\Lab1\\lee_12345.txt"));
            String line = "";
            while((line = br.readLine()) != null){
                System.out.println(line);
            }
            br.close();
            
            
            */
        }catch (IOException e){
            System.out.println(e);
        }       
        
        // Part 3
        try{
            s = new Scanner(System.in);
            System.out.println("\nEnter your text here: ");
            String text = s.nextLine();
            PrintWriter p = new PrintWriter(new FileOutputStream("src\\Lab1\\lee_12345.txt", true));
            p.println();
            p.println("Thursday, 18 June 2021.");
            p.println();
            p.println(text);
            p.close();
            
            s.close();
            
            // Read from the file again
            s = new Scanner(new FileInputStream("src\\Lab1\\lee_12345.txt"));
            System.out.println("The letter: ");
            while(s.hasNextLine()){
                String line = s.nextLine();
                System.out.println(line);
            }
            s.close();
        }catch(IOException e){
            System.out.println(e);
        }

    }
}
/*
BufferedWriter bw = new BufferedWriter(new FileWriter("files\\lee_123465.txt", true));
bw.write("askas");
bw.close();
*/