package Lab1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner s;
        
        // text1, separated by comma
        try {
            s = new Scanner(new FileInputStream("src\\Lab1\\text1.txt"));
            int num = 0;
            while(s.hasNextLine()){
                String line = s.nextLine();
                String[] items = line.split(",");
                num += items.length;
                for(int i=0; i<items.length; i++){
                    System.out.print(items[i]);
                }
                System.out.println("");
            }
            System.out.println("Number of characters is: " + num);
            s.close();
        }catch (IOException e){
            System.out.println(e);
        }
        
//        // text2, separated by comma and space
//        try {
//            s = new Scanner(new FileInputStream("src\\Lab1\\text2.txt"));
//            int num = 0;
//            while(s.hasNextLine()){
//                String line = s.nextLine();
//                String[] items = line.split(", ");
//                for(int i=0; i<items.length; i++){
//                    System.out.print(items[i] + " ");
//                    num += items[i].length();
//                }
//                System.out.println("");
//            }
//            System.out.println("Number of characters is: " + num);
//            s.close();
//        }catch (IOException e){
//            System.out.println(e);
//        }
//        
//        // text3, separated by semicolon and space
//        try {
//            s = new Scanner(new FileInputStream("src\\Lab1\\text3.txt"));
//            int num = 0;
//            while(s.hasNextLine()){
//                String line = s.nextLine();
//                String[] items = line.split("; ");
//                for(int i=0; i<items.length; i++){
//                    System.out.print(items[i] + " ");
//                    num += items[i].length() -1; // ignore the full stop
//                }
//                System.out.println("");
//            }
//            System.out.println("Number of characters is: " + num);
//            s.close();
//        }catch (IOException e){
//            System.out.println(e);
//        }
//        
        // text4, separated by numbers
        try {
            s = new Scanner(new FileInputStream("src\\Lab1\\text4.txt"));
            int num = 0;
            String cur = "";
            while(s.hasNextLine()){
                String line = s.nextLine();
                String arr[] = line.split("\\d+");
                for(String x : arr) {
                    System.out.print(x);
                    num += x.length();
                }
                System.out.println("");
            }
            System.out.println("Number of characters is: " + num);
            s.close();
        }catch (IOException e){
            System.out.println(e);
        }
    }
}
