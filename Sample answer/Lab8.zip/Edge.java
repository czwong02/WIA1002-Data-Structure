package Lab8;

public class Edge<T extends Comparable<T>, N extends Comparable<N>> {
    Vertex<T,N> toVertex;
    N weight;
    Edge<T, N> nextEdge;
    
    public Edge(){
        toVertex = null;
        weight = null;
        nextEdge = null;
    }
    public Edge(Vertex<T,N> destination, N val, Edge<T,N> e){
        toVertex = destination;
        weight = val;
        nextEdge = e;
    }
}