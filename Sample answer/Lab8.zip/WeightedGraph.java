package Lab8;

import java.util.ArrayList;

public class WeightedGraph<T extends Comparable<T>, N extends Comparable<N>> {
    Vertex<T,N> head;
    int size;
    
    public WeightedGraph(){
        head = null;
        size = 0;
    }
    public void clear(){
        head = null;
        size = 0;
    }
    public int getSize(){
        return size;
    }
    public int getIndeg(T val){
        Vertex<T,N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(val)) return temp.indeg;
            temp = temp.nextVertex;
        }
        return -1;
    }
    public int getOutdeg(T val){
        Vertex<T,N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(val)) return temp.outdeg;
            temp = temp.nextVertex;
        }
        return -1;
    }
    public boolean hasVertex(T val){
        Vertex<T,N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(val)) return true;
            temp = temp.nextVertex;
        }
        return false;
    }
    public boolean addVertex(T val){
        Vertex<T,N> temp = head;
        Vertex<T,N> newVertex = new Vertex(val, null);
        if (head == null){
            head = newVertex;
            size++;
            return true;
        }
        Vertex<T, N> prev = head;
        while(temp != null){ // go through all the vertex
            if (temp.vertexInfo.equals(val)) return false; // already inside the graph
            prev = temp;
            temp = temp.nextVertex;
        }
        prev.nextVertex = newVertex;
        size++;
        return true;
    }
    public int getIndex(T val){
        Vertex<T,N> temp = head;
        int idx = 0;
        while(temp != null){
            if (temp.vertexInfo.equals(val)) return idx;
            idx++;
            temp = temp.nextVertex;
        }
        return -1;
    }
    public ArrayList<T> getAllVertexObject(){
        ArrayList<T> res = new ArrayList();
        Vertex<T,N> temp = head;
        while(temp != null){
            res.add(temp.vertexInfo);
            temp = temp.nextVertex;
        }
        return res;
    }
    public ArrayList<Vertex<T,N>> getAllVertices(){
        ArrayList<Vertex<T,N>> res = new ArrayList();
        Vertex<T,N> temp = head;
        while(temp != null){
            res.add(temp);
            temp = temp.nextVertex;
        }
        return res;
    }
    public T getVertex(int pos){
        if (pos < 0 || pos >= size) return null;
        Vertex<T, N> temp = head;
        for (int i = 0; i < pos; i++) {
            temp = temp.nextVertex;
        }
        return temp.vertexInfo;
    }
    public boolean addEdge(T source, T destination, N weight){
        Vertex<T, N> src = head;
        while(src != null){
            if (src.vertexInfo.equals(source)){ // found source
                Vertex<T,N> dest = head;
                while(dest != null){
                    if (dest.vertexInfo.equals(destination)){ // found dest
                        Edge<T,N> newEdge = new Edge(dest, weight, src.firstEdge); 
                        src.firstEdge = newEdge;
                        src.outdeg++; 
                        dest.indeg++;
                        return true;
                    }
                    dest = dest.nextVertex;
                }
                return false; // destination not found
            }
            src = src.nextVertex;
        }
        return false;
    }
    public boolean addUndirectedEdge(T source, T destination, N weight){
        return addEdge(source, destination, weight) && addEdge(destination, source, weight);
    }
    /*
    public boolean addUndirectedEdge(T source, T destination, N weight){
        Vertex<T, N> src = head;
        while(src != null){
            if (src.vertexinfo.equals(source)){ // found source
                Vertex<T,N> dest = head;
                while(dest != null){
                    if (dest.vertexinfo.equals(destination)){ // found dest
                        Edge<T,N> srcNewEdge = new Edge(dest, weight, src.firstEdge); 
                        Edge<T,N> destNewEdge = new Edge(src, weight, dest.firstEdge); 
                        src.firstEdge = srcNewEdge;
                        dest.firstEdge = destNewEdge;
                        src.outdeg++; src.indeg++;
                        dest.indeg++; dest.outdeg++;
                        return true;
                    }
                    dest = dest.nextVertex;
                }
                return false; // destination not found
            }
            src = src.nextVertex;
        }
        return false;
    }
*/
    public boolean hasEdge(T source, T destination){
        Vertex<T, N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(source)){ // found the source
                Edge<T,N> edge = temp.firstEdge;
                while(edge != null){
                    if (edge.toVertex.vertexInfo.equals(destination)) return true;
                    edge = edge.nextEdge;
                }
                return false; // destination not found or no edge
            }
            temp = temp.nextVertex;
        }
        return false;
    }
    public N getEdgeWeight(T source, T destination){
        Vertex<T, N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(source)){ // found source
                Edge<T,N> edge = temp.firstEdge;
                while(edge != null){
                    if (edge.toVertex.vertexInfo.equals(destination)) return edge.weight;
                    edge = edge.nextEdge;
                }
                return null; // destination not found or no edge
            }
            temp = temp.nextVertex;
        }
        return null;
    }
    public ArrayList<T> getNeighbours(T val){
        ArrayList<T> res = new ArrayList();
        Vertex<T, N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(val)){
                Edge<T,N> edge = temp.firstEdge;
                while(edge != null){
                    res.add(edge.toVertex.vertexInfo);
                    edge = edge.nextEdge;
                }
                return res;
            }
            temp = temp.nextVertex;
        }
        return res;
    }
    public void printEdges(){
        Vertex<T, N> temp = head;
        while(temp != null){
            System.out.print("# " + temp.vertexInfo + " : ");
            Edge<T, N> edge = temp.firstEdge;
            while(edge != null){
                System.out.print("[" + temp.vertexInfo + "," + edge.toVertex.vertexInfo + "] ");
                edge = edge.nextEdge;
            }
            temp = temp.nextVertex;
            System.out.println("");
        }
    }
    public boolean removeEdge(T source, T destination){
        if (!hasEdge(source, destination)) return false;
        Vertex<T, N> temp = head;
        while(temp != null){
            if (temp.vertexInfo.equals(source)){
                Edge<T,N> currEdge = temp.firstEdge;
                if (currEdge.toVertex.vertexInfo.equals(destination)){ // if the first edge is dest
                    temp.firstEdge = currEdge.nextEdge;
                    currEdge.nextEdge = null;
                }else{
                    Edge<T, N> prevEdge = currEdge;
                    while(currEdge != null){
                        if (currEdge.toVertex.vertexInfo.equals(destination)){ // found the destination edge
                            prevEdge.nextEdge = currEdge.nextEdge;
                            currEdge.nextEdge = null; 
                            break;
                        }
                        prevEdge = currEdge;
                        currEdge = currEdge.nextEdge;
                    }
                    temp.outdeg--;
                    currEdge.toVertex.indeg--;
                    return true;
                }
            }
            temp = temp.nextVertex;
        }
        return false;
    }
}

