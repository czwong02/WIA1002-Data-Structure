
import java.util.Scanner;


public class Q3 {
    public static class Pair{
        private Integer buyCount;
        private Integer buyPrice;
        
        public Pair(Integer count, Integer price){
            buyCount = count;
            buyPrice = price;
        }

        public Integer getBuyCount() {
            return buyCount;
        }

        public Integer getBuyPrice() {
            return buyPrice;
        }
        public void modifyCount(Integer k){
            buyCount += k;
        }
        public String toString(){
            return String.format("{Units: %s , Buy Price: %s}", buyCount, buyPrice);
        }
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        MyQueue<Pair> q = new MyQueue();
        
        String query;
        int profit = 0;
        
        while(true){
            System.out.print("Enter your query (In format 'Buy / Sell x shares at $y each'): ");
            query = s.nextLine();
            if (query.isBlank()) break;
            
            String temp[] = query.split(" "); // size of 6
            int share = Integer.parseInt(temp[1]);
            int price = Integer.parseInt(temp[4].substring(1)); // remove $ sign
            
            if (temp[0].equalsIgnoreCase("Buy")){
                System.out.println("Buying now...");
                q.enqueue(new Pair(share, price));
                System.out.println("The queue now is: " + q);
            }else{
                System.out.println("Selling now...");
                while(share > 0 && !q.isEmpty()){
                    int priceDiff = price - q.peek().getBuyPrice();
                    if (share >= q.peek().getBuyCount()){ // if the share is larger than the current share in hand
                        share -= q.peek().getBuyCount();
                        profit += priceDiff * q.peek().getBuyCount();
                        q.dequeue();
                    }else{ // if the share is smaller than out stock in hand
                        profit += priceDiff * share;
                        q.peek().modifyCount(-share);
                        share = 0;
                    }
                    System.out.println("Total Capital Gain / Loss: " + profit);
                }
                if (share > 0){
                    System.out.println("No shares to sell!");
                }
                System.out.println("The queue now is: " + q);
            }
        }
        System.out.println("Final Capital Gain / Loss: " + profit);
    }
}
/*
Buy 100 shares at $10 each
Buy 50 shares at $20 each
Sell 50 shares at $20 each
Sell 60 shares at $30 each
Sell 50 shares at $35 each

*/
