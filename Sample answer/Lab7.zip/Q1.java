
public class Q1 {

    public static void main(String[] args) {
        MyQueue<String> fruitQ = new MyQueue(new String[]{"Durian", "Blueberry"});
        
        fruitQ.enqueue("Apple");
        fruitQ.enqueue("Orange");
        fruitQ.enqueue("Grapes");
        fruitQ.enqueue("Cherry");
        
        System.out.println("The queue is:");
        System.out.println(fruitQ);
        
        System.out.println("The top item is " + fruitQ.peek());
        System.out.println("The queue size is " + fruitQ.getSize());
        
        fruitQ.dequeue();
        System.out.println("Removed Durian from the queue");
        System.out.println("The item in index 2 is " + fruitQ.getElement(2));
        
        System.out.println("Queue consists of Cherry: " + fruitQ.contains("Cherry"));
        System.out.println("Queue consists of Durian: " + fruitQ.contains("Durian"));
        
        System.out.println("The queue now is: ");
        while(!fruitQ.isEmpty()){
            System.out.print(fruitQ.dequeue() + " ");
        }
        System.out.println("");
    }
}
