package Lab2;

public class Q6 {

    public static void main(String[] args) {
        Integer[][] arr = {{4, 5, 6}, {1, 2, 3}};
        System.out.println("Min: " + MinMaxTwoDArray.min(arr));
        System.out.println("Max: " + MinMaxTwoDArray.max(arr));
    }

}
