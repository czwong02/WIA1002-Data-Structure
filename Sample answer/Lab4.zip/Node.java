
package Lab4;

public class Node<E> {
    E element;
    Node<E> next;
    
    public Node(){
        
    }
    
    public Node(E e){
        element = e;
    }
}
