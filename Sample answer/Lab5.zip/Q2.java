package Lab5;

import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        SList<String> students = new SList();
        
        System.out.println("Enter your student name list. Enter 'n' to end.....");
        String name = "";
        while(true){
            name = s.nextLine();
            if (name.equals("n")) break;
            students.add(name);
        }
        
        System.out.println("\nYou have entered the following students' name: ");
        students.printList();
        
        System.out.println("\nThe number of students entered is : " + students.getSize());
        System.out.println("\nAll the names entered are correct? Enter 'r' to rename the student name, 'n' to proceed.");
        String choice = s.nextLine();
        
        if (choice.equals("r")){
            System.out.println("\nEnter the existing student name that u want to rename : ");
            name = s.nextLine();
            System.out.println("\nEnter the new name : ");
            String newName = s.nextLine();
            students.replace(name, newName);
            System.out.println("\nThe new student list is : ");
            students.printList();
        }
        
        System.out.println("\nDo you want to remove any of your student name? Enter 'y' for yes, 'n' to proceed.");
        choice = s.nextLine();
        
        if (choice.equals("y")){
            System.out.println("\nEnter a student name to remove : ");
            name = s.nextLine();
            students.removeElement(name);
            System.out.print("\nThe number of updated student is : " + students.getSize());
            System.out.println("\nThe updated student list is : ");
            students.printList();
        }
        
        System.out.println("\nAll student data captured complete. Thank you!");
    }
}
/*
Rahmat
Alice
Fatymah
Yoke Ling
Maniam
Abu
n
*/