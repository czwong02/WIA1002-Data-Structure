package Lab5;

public class SNode<E> {
    E element;
    SNode<E> next;
    
    public SNode(){
    }
    public SNode(E e){
        element = e;
    }
}
