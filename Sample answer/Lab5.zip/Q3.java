
package Lab5;

public class Q3 {
    public static void main(String[] args) {
        DoublyLinkedList<Integer> list = new DoublyLinkedList();
        
        list.addFirst(1);
        list.addLast(10);
        list.addLast(100);
        list.remove(2);
        list.add(2, 2);
        list.iterateForward();
        
        list.iterateBackward();
        System.out.println("Size of Doubly Linked List: " + list.size());
        System.out.printf("Successfully clear %d node(s)\n", list.size());
        list.clear();
        System.out.println("Size of current Doubly Linked List: " + list.size());
        
    }
}
