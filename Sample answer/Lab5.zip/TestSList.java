package Lab5;

public class TestSList {
    public static void main(String[] args) {
        SList<String> list = new SList();
        list.appendEnd("Linked list");
        list.appendEnd("is");
        list.appendEnd("easy");
        
        list.display();
        
        System.out.println("Removed the first string: " + list.removeInitial());
        list.display();
        
        System.out.println("\"difficult\" is in the list: " + list.contains("difficult"));
        list.clear();
        list.display();
    }
}
