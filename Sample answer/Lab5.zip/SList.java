package Lab5;

public class SList<E> {
    private SNode<E> head;
    private SNode<E> tail;
    private int size;
    
    public SList(){
        size = 0;
    } 
    public int size(){
        return size;
    }
    public void appendEnd(E e){
        SNode<E> newNode = new SNode(e);
        if (tail == null){
            head = tail = newNode;
        }else{
            tail.next = newNode;
            tail = tail.next;
        }
        size++;
    }
    public E removeInitial(){
        if (head == null) return null;
        SNode<E> tobeRemoved = head;
        head = head.next;
        size--;
        if (head == null) tail = null; // incase left 0 element
        return tobeRemoved.element;
    }
    public boolean contains(E e){
        SNode<E> cur = head;
        while(cur != null){
            if (cur.element.equals(e)) return true;
            cur = cur.next;
        }
        return false;
    }
    public void clear(){
        head = tail = null;
        System.out.printf("successfully clear %d node(s)\n", size);
        size = 0;
    }
    public void display(){
        SNode<E> cur = head;
        while(cur != null){
            System.out.print(cur.element + " --> ");
            cur = cur.next;
        }
        System.out.println("");
    }
    
    // For question 2
    public void add(E e){
        SNode<E> newNode = new SNode(e);
        if (tail == null){
            head = tail = newNode;
        }else{
            tail.next = newNode;
            tail = tail.next;
        }
        size++;
    }
    public void removeElement(E e){
        SNode<E> prev = null, cur = head;
        while(cur != null){
            if (cur.element.equals(e)){
                if (cur == head){
                    head = head.next;
                    if (head == null) tail = null; // if 1 element in the list
                }else{
                    prev.next = cur.next;
                    if (cur.next == null) tail = prev;
                }
                size--;
                return;
            }
            prev = cur;
            cur = cur.next;
        }
    }
    public void printList(){
        SNode<E> cur = head;
        while(cur != null){
            if (cur.next != null) System.out.print(cur.element + ", ");
            else System.out.print(cur.element + ".");
            cur = cur.next;
        }
        System.out.println("");
    }
    public int getSize(){
        return size;
    }
    public void replace(E e, E newE){
        SNode<E> cur = head;
        while(cur != null){
            if (cur.element.equals(e)) cur.element = newE;
            cur = cur.next;
        }
    }
}
